from task import Task

class TaskService:
    def __init__(self):
        self.tasks = {}

    # Add a new task
    def addTask(self, task):
        taskID = task.getTaskID()
        if taskID in self.tasks:
            raise ValueError("Task ID already exists")
        self.tasks[taskID] = task

    # Delete a task
    def deleteTask(self, taskID):
        if taskID not in self.tasks:
            raise ValueError("Task ID not found")
        del self.tasks[taskID]

    # Update values
    def updateName(self, taskID, name):
        task = self._getTask(taskID)
        task.setName(name)

    def updateDescription(self, taskID, description):
        task = self._getTask(taskID)
        task.setDescription(description)

    # Getters
    def getTaskID(self, taskID):
        task = self._getTask(taskID)
        return task.getTaskID()

    def getName(self, taskID):
        task = self._getTask(taskID)
        return task.getName()
    
    def getDescription(self, taskID):
        task = self._getTask(taskID)
        return task.getDescription()


    # Helper method to get a task by ID
    def _getTask(self, taskID):
        if taskID not in self.tasks:
            raise ValueError("Task ID not found")
        return self.tasks[taskID]

