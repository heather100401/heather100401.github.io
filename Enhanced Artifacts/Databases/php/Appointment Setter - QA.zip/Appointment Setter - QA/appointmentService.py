from appointment import Appointment

class AppointmentService:
    def __init__(self):
        self.appointments = {}

    # Add a new appointment
    def addAppointment(self, appointment):
        appointmentID = appointment.getAppointmentID()
        if appointmentID in self.appointments:
            raise ValueError("Appointment ID already exists")
        self.appointments[appointmentID] = appointment

    # Delete an appointment
    def deleteAppointment(self, appointmentID):
        if appointmentID not in self.appointments:
            raise ValueError("Appointment ID not found")
        del self.appointments[appointmentID]

    # Getters
    def getAppointmentID(self, appointmentID):
        appointment = self._getAppointment(appointmentID)
        return appointment.getAppointmentID()

    def getDate(self, appointmentID):
        appointment = self._getAppointment(appointmentID)
        return appointment.getDate()

    def getDescription(self, appointmentID):
        appointment = self._getAppointment(appointmentID)
        return appointment.getDescription()

    # Helper method to get an appointment by ID
    def _getAppointment(self, appointmentID):
        if appointmentID not in self.appointments:
            raise ValueError("Appointment ID not found")
        return self.appointments[appointmentID]
