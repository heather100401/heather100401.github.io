class Contact:
    def __init__(self, contactID, firstName, lastName, phone, address):
        self._contactID = contactID              # Unique, cannot be updated, max length of 10
        self._firstName = firstName              # Cannot be null, max length 10
        self._lastName = lastName                # Cannot be null, max length 10
        self._phone = phone                      # Cannot be null, exactly 10 digits
        self._address = address                  # Cannot be null, max length 30
    
    #getters
    def getContactID(self):
        return self._contactID
    
    def getFirstName(self):
        return self._firstName
    
    def getLastName(self):
        return self._lastName
    
    def getPhone(self):
        return self._phone
    
    def getAddress(self):
        return self._address

    #setters
    def setFirstName(self, firstName):
        self._firstName = firstName

    def setLastName(self, lastName):
        self._lastName = lastName   

    def setPhone(self, phone):
        self._phone = phone

    def setAddress(self, address):
        self._add = address 

