class Task:
    def __init__(self, taskID, name, description):
        self._taskID = taskID                # Unique, cannot be updated, max length 10
        self._name = name                    # Cannot be null, max length 20
        self._description = description      # Cannot be null, max length 50

    #getters
    def getTaskID(self):
        return self._taskID
    
    def getName(self):
        return self._name
    
    def getDescription(self):
        return self._description


    #setters
    def setName(self, name):
        self._name = name

    def setDescription(self, description):
        self._description = description   
