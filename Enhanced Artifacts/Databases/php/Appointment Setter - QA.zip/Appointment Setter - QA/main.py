from appointment import Appointment
from appointmentService import AppointmentService
from contact import Contact
from contactService import ContactService
from task import Task
from taskService import TaskService
from datetime import datetime

def main():
    appointmentService = AppointmentService()
    contactService = ContactService()
    taskService = TaskService()

    while True:
        print("Hello!")
        print("\nMain Menu:")
        print("1. Appointments")
        print("2. Contact Information")
        print("3. Tasks")
        print("4. Exit")
        choice = input("Choose an option: ")

        if choice == '1':
            while True:
                print("\nAppointments:")
                print("1. Make a New Appointment")
                print("2. Cancel Appointment")
                print("3. View Upcoming Appointments")
                print("4. Back to Main Menu")
                appt_choice = input("Choose an option: ")

                if appt_choice == '1':
                    try:
                        appt_id = input("Enter Appointment ID (<=10 characters): ")
                        # Validate appointment ID
                        if len(appt_id) > 10:
                            raise ValueError("Appointment ID must be less than 10 characters.")
                        date_str = input("Enter date (mm/dd/yyyy): ")
                        # Validate and convert date
                        date = datetime.strptime(date_str, "%m/%d/%Y")
                        if date < datetime.now():
                            raise ValueError("Date must be in the future.")
                        description = input("Enter description (<=50 characters): ")
                        if len(description) > 50:
                            raise ValueError("Description must be less than 50 characters.")
                        appointment = Appointment(appt_id, date, description)
                        appointmentService.addAppointment(appointment)
                        print("Appointment added successfully.")
                    except Exception as e:
                        print(f"Error: {e}")

                elif appt_choice == '2':
                    appt_id = input("Enter Appointment ID to delete: ")
                    try:
                        appointmentService.deleteAppointment(appt_id)
                        print("Appointment deleted.")
                    except Exception as e:
                        print(f"Error: {e}")

                elif appt_choice == '3':
                    print("Upcoming Appointments:")
                    for appt_id in appointmentService.appointments:
                        appt = appointmentService.appointments[appt_id]
                        print(f"{appt.getAppointmentID()} - {appt.getDate().strftime('%m/%d/%Y')} - {appt.getDescription()}")

                elif appt_choice == '4':
                    break

        elif choice == '2':
            while True:
                print("\nContact Information:")
                print("1. Add New Contact")
                print("2. Delete Contact")
                print("3. Update Contact Information")
                print("4. View Contact Information")
                print("5. Back to Main Menu")
                contact_choice = input("Choose an option: ")

                if contact_choice == '1':
                    try:
                        contact_id = input("Contact ID: ")
                        first_name = input("First Name: ")
                        last_name = input("Last Name: ")
                        phone = input("Phone (10 digits): ")
                        address = input("Address: ")

                        contact = Contact(contact_id, first_name, last_name, phone, address)
                        contactService.addContact(contact)
                        print("Contact added.")
                    except Exception as e:
                        print(f"Error: {e}")

                elif contact_choice == '3':
                    contact_id = input("Enter contact ID to update: ")
                    update_field = input("Update:\n1. First Name\n2. Last Name\n3. Phone\n4. Address\nChoose: ")
                    new_val = input("Enter new value: ")

                    try:
                        if update_field == '1':
                            contactService.updateFirstName(contact_id, new_val)
                        elif update_field == '2':
                            contactService._getContact(contact_id).setLastName(new_val)
                        elif update_field == '3':
                            contactService._getContact(contact_id).setPhone(new_val)
                        elif update_field == '4':
                            contactService._getContact(contact_id).setAddress(new_val)
                        print("Contact updated.")
                    except Exception as e:
                        print(f"Error: {e}")

                elif contact_choice == '5':
                    break

        elif choice == '3':
            while True:
                print("\nTasks:")
                print("1. Add New Task")
                print("2. Delete Task")
                print("3. Update Task")
                print("4. View Task")
                print("5. Back to Main Menu")
                task_choice = input("Choose an option: ")

                if task_choice == '1':
                    try:
                        task_id = input("Task ID: ")
                        name = input("Task Name: ")
                        desc = input("Task Description: ")
                        task = Task(task_id, name, desc)
                        taskService.addTask(task)
                        print("Task added.")
                    except Exception as e:
                        print(f"Error: {e}")

                elif task_choice == '3':
                    task_id = input("Enter task ID to update: ")
                    update_field = input("Update:\n1. Name\n2. Description\nChoose: ")
                    new_val = input("Enter new value: ")

                    try:
                        if update_field == '1':
                            taskService.updateName(task_id, new_val)
                        elif update_field == '2':
                            taskService.updateDescription(task_id, new_val)
                        print("Task updated.")
                    except Exception as e:
                        print(f"Error: {e}")

                elif task_choice == '5':
                    break

        elif choice == '4':
            print("Goodbye!")
            break

        else:
            print("Invalid input. Please choose a valid option.")


main()
exit()