from contact import Contact

class ContactService:
    def __init__(self):
        self.contacts = {}

    # Add a new contact
    def addContact(self, contact):
        contactID = contact.getContactID()
        if contactID in self.contacts:
            raise ValueError("Contact ID already exists")
        self.contacts[contactID] = contact

    # Delete a contact
    def deleteContact(self, contactID):
        if contactID not in self.contacts:
            raise ValueError("Contact ID not found")
        del self.contacts[contactID]

    # Update values

    # Update values
    def updateFirstName(self, contactID, firstName):
        contact = self._getContact(contactID)
        contact.setFirstName(firstName)

    def updateLastName(self, contactID, lastName):
        contact = self._getContact(contactID)
        contact.setLastName(lastName)

    def updatePhone(self, contactID, phone):
        contact = self._getContact(contactID)
        contact.setPhone(phone)

    def updateAddress(self, contactID, address):
        contact = self._getContact(contactID)
        contact.setAddress(address)

    # Getters
    def getContactID(self, contactID):
        contact = self._getContact(contactID)
        return contact.getcontactID()

    def getFirstName(self, contactID):
        contact = self._getContact(contactID)
        return contact.getFirstName()
    
    def getLastName(self, contactID):
        contact = self._getContact(contactID)
        return contact.getLastName()
    
    def getPhone(self, contactID):
        contact = self._getContact(contactID)
        return contact.getPhone()
    
    def getAddress(self, contactID):
        contact = self._getContact(contactID)
        return contact.getAddress()
    

    # Helper method to get a contact by ID
    def _getContact(self, contactID):
        if contactID not in self.contacts:
            raise ValueError("Contact ID not found")
        return self.contacts[contactID]
