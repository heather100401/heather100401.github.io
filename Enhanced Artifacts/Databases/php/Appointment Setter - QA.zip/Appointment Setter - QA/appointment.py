from datetime import datetime

class Appointment:
    def __init__(self, appointmentID, date, description):
        self._appointmentID = appointmentID              # Unique, cannot be updated, max length 10
        self._date = date                                # Cannot be null or in the past
        self._description = description                  # Cannot be null, max length 50
        
    # Getters
    def getAppointmentID(self):
        return self._appointmentID
    
    def getDate(self):
        return self._date
    
    def getDescription(self):
        return self._description

    # Setters
    def setDate(self, date):
        self._date = date

    def setDescription(self, description):
        self._description = description
